import math
class Shape:
    num=0
    def __init__(self,colour):

        self.colour=colour
        self._area=0
        Shape.num+=1
        print(Shape.num)

    def print(self):
        print(f"Colour of shape is {self.colour}")

    def calc_area(self):
        pass

class Rectangle(Shape):
    def __init__(self,colour,length,width):
        super().__init__(colour)
        self.length=length
        self.width=width

    def print(self):
        super().print()
        print(f"Rectangle Length: {self.length} and width: {self.width}")

    def calc_area(self):
        self._area=self.length*self.width
        print(f"Area is: {self._area}")

class Triangle(Shape):
    def __init__(self,colour,base,height):
        super().__init__(colour)
        self.base=base
        self.height=height

    def print(self):
        super().print()
        print(f"Triangle base is: {self.base} and height is {self.height}")

    def calc_area(self):
        self._area=0.5*self.base*self.height
        print(f"Area is: {self._area}")

class Circle(Shape):
    def __init__(self,colour,radius):
        super().__init__(colour)
        self._radius=radius

    def print(self):
        super().print()
        print(f"Circle radius is: {self._radius}")

    def calc_area(self):
        self._area=math.pi*self._radius*self._radius
        print(f"Area is: {self._area:.2f}")

class Cylinder(Circle):
    def __init__(self,colour,radius,height):
        super().__init__(colour,radius)
        self.height=height
        self.volume=0

    def print(self):
        super().print()
        print(f"Cylinder height is: {self.height}")

    def calc_area(self):
        self._area=((2*math.pi*self._radius*self._radius)+
                    (2*math.pi*self._radius*self.height))
        print(f"Area is: {self._area:.2f}")

    def calc_volume(self):
        self.volume=math.pi*self._radius*self._radius*self.height
        print(f"Volume is: {self.volume:.2f}")

#main body
s1=Rectangle("red",4.0,5.0)
s1.print()
s1.calc_area()

s2=Triangle("blue",4.0,5.0)
s2.print()
s2.calc_area()

s3=Circle("black",9.0)
s3.print()
s3.calc_area()


s4=Cylinder("Indigo",5.0,9)
s4.print()
s4.calc_area()
s4.calc_volume()

