# import random
#
# class Counter:
#     def __init__(self):
#         self.__value = 0
#
#     def get_value(self):
#         return self.__value
#
#     def increment(self):
#         self.__value += 1
#
#
# head_count = Counter()
# tail_count = Counter()
# for i in range(100):
#     if random.random() < 0.5: # There's a 50/50 chance that this is true.
#         head_count.increment()
#     else:
#         tail_count.increment()
# print("There were " ,head_count.get_value(), " heads.")
# print("There were " ,tail_count.get_value(), " tails.")



class Bottle:
    number_of_bottles = 0

    def __init__(self, capacity_in=None):
        if capacity_in is not None and capacity_in > 0:
            self.__capacity = capacity_in
        else:
            self.__capacity = 1
        self.__current_quantity = 0
        Bottle.number_of_bottles += 1

    def get_current_quantity(self):
        return self.__current_quantity

    def get_capacity(self):
        return self.__capacity

    def fill_fully(self):
        self.__current_quantity = self.__capacity

    def empty(self):
        self.__current_quantity = 0

    def pour(self, amount):
        if self.__current_quantity >= amount:
            self.__current_quantity -= amount
            return True
        else:
            return False

    def add(self, amount):
        if self.__current_quantity + amount <= self.__capacity:
            self.__current_quantity += amount
            return True
        else:
            return False

    def print(self):
        print("Bottle capacity: ", self.__capacity)
        print("Bottle current quantity: ",self.__current_quantity)




# main body of code
print("The number of bottles ", Bottle.number_of_bottles)
b1 = Bottle(2)
b2 = Bottle(7)
print("The number of bottles ", Bottle.number_of_bottles)

b1.fill_fully()
b2.fill_fully()
if b2.pour(2):
    print("2 litres poured from 2nd bottle")
else:
    print("2 litres not poured")

b2.print()

if b2.add(8):
    print("8 litres added successfully")
else:
    print("Unable to add the 8 litres to the 2nd bottle - overflow occurred")

if b2.pour(3):
    print("3 litres poured from the 2nd bottle")
else:
    print("Not enough water in the bottle to pour 3 litres")
print("Water in the 2nd bottle", b2.get_current_quantity())

bottle1contents = b1.get_current_quantity()
bottle2capacity = b2.get_capacity()
if b2.get_current_quantity() + b1.get_current_quantity() <= b2.get_capacity():
    b2.add(bottle1contents)
    b1.empty()
    print("Contents of bottle 1 added to bottle 2")
else:
    print("Unable to add to the contents of the 1st bottle to the 2nd bottle - not enough capacity in 2nd bottle")

# or
# if b2.add(b1.get_current_quantity()):
#     b1.empty()
#     print("Contents of bottle 1 added to bottle 2")
# else:
#     print("Unable to add to the contents of the 1st bottle to the 2nd bottle - not enough capacity in 2nd bottle")
b1.print()
b2.print()
